package com.mikedev.mutxamelcf.dao;

import com.mikedev.mutxamelcf.model.Usuario;

public interface UsuarioDao {

	Usuario validarUsuario(String usuario, String password);

}
