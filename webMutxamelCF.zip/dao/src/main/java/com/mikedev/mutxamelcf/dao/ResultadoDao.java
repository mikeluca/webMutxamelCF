package com.mikedev.mutxamelcf.dao;

import java.util.List;

import com.mikedev.mutxamelcf.model.Resultado;

public interface ResultadoDao {

	void actualizarResultado(Resultado resultado);

	List<Resultado> obtenerResultados(String deporte);

	Resultado obtenerResultadoPrimerEquipo();

}
